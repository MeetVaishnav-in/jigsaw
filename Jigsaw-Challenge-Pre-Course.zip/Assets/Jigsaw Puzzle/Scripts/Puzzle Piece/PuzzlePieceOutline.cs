using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzlePieceOutline : MonoBehaviour
{
    [Header(" Elements ")]
    [SerializeField] private Renderer renderer;

    public void Generate(Vector2[] vertices, float thickness)
    {
        List<Vector2> inlineVertices = Outliner2D.CreateInsideOutline(vertices, thickness);
        List<Vector2> outlineVertices = Outliner2D.CreateInsideOutline(vertices, -thickness);

        int maxIndex = inlineVertices.Count;

        Mesh mesh = new Mesh();

        inlineVertices.AddRange(outlineVertices);

        List<Vector3> verts = new List<Vector3>();
        foreach (Vector2 v in inlineVertices)
            verts.Add(v);

        mesh.vertices = verts.ToArray();

        List<int> triangles = new List<int>();

        for (int i = 0; i < maxIndex - 1; i++)
        {
            triangles.Add(i + 0);
            triangles.Add(i + maxIndex + 1);
            triangles.Add(i + 1);

            triangles.Add(i + 0);
            triangles.Add(i + maxIndex);
            triangles.Add(i + maxIndex + 1);
        }

        // Add the last triangles
        int j = maxIndex - 1;

        triangles.Add(inlineVertices.Count - 1);
        triangles.Add(j + 1);
        triangles.Add(0);

        triangles.Add(inlineVertices.Count - 1);
        triangles.Add(0);
        triangles.Add(j);

        List<Vector2> uvs = new List<Vector2>();

        for (int i = 0; i < inlineVertices.Count; i++)
            uvs.Add(inlineVertices[i] + Vector2.one / 2);

        mesh.triangles = triangles.ToArray();
        mesh.uv = uvs.ToArray();

        mesh.RecalculateBounds();

        GetComponent<MeshFilter>().mesh = mesh;
    }

    public void ConfigureMaterial(Vector2 tiling, Vector2 offset)
    {
        renderer.material.SetVector("_Tiling", tiling);
        renderer.material.SetVector("_Offset", offset);
    }

    public void SetAlpha(float alpha)
    {
        float initialAlpha = renderer.material.GetFloat("_Exposure");
        LeanTween.value(renderer.gameObject, (value) => renderer.material.SetFloat("_Exposure", value), initialAlpha, alpha, 1);
    }
}
