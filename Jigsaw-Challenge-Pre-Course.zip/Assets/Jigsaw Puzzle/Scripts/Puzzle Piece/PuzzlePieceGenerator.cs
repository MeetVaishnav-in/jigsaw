using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Dreamteck.Splines;
using NaughtyAttributes;

public class PuzzlePieceGenerator : MonoBehaviour
{
    [Header(" Data ")]
    [SerializeField] private JigShapeSO jigShape;

    [Header(" Settings ")]
    [OnValueChanged("Configure")] [Range(0, 2)] [SerializeField] private int rightTrit;
    [OnValueChanged("Configure")] [Range(0, 2)] [SerializeField] private int bottomTrit;
    [OnValueChanged("Configure")] [Range(0, 2)] [SerializeField] private int leftTrit;
    [OnValueChanged("Configure")] [Range(0, 2)] [SerializeField] private int topTrit;

    [Header(" Mid Offsets ")]
    [OnValueChanged("Configure")] [Range(0f, 1f)] [SerializeField] private float rightOffset;
    [OnValueChanged("Configure")] [Range(0f, 1f)] [SerializeField] private float bottomOffset;
    [OnValueChanged("Configure")] [Range(0f, 1f)] [SerializeField] private float leftOffset;
    [OnValueChanged("Configure")] [Range(0f, 1f)] [SerializeField] private float topOffset;

    [Header(" Components ")]
    [SerializeField] private Renderer renderer;

    [Header(" Outline Settings ")]
    [SerializeField] private float thickness;
    private PuzzlePieceOutline outline;

    [Button]
    public void Randomize()
    {
        float minOffset = .4f;
        float maxOffset = .6f;

        int[] trits = new int[] { Random.Range(0, 3), Random.Range(0, 3), Random.Range(0, 3), Random.Range(0, 3) };
        float[] offsets = new float[] { Random.Range(minOffset, maxOffset), Random.Range(minOffset, maxOffset), Random.Range(minOffset, maxOffset), Random.Range(minOffset, maxOffset) };

        Configure(trits, offsets);
    }

    public void SetOutlineThickness(float thickness)
    {
        this.thickness = thickness;
    }

    public void SetOutlineAlpha(float alpha)
    {
        outline.SetAlpha(alpha);
    }

    // Start is called before the first frame update
    public void Configure(int[] trits, float[] offsets)
    {
        // Setup the trits 
        rightTrit   = trits[0];
        bottomTrit  = trits[1];
        leftTrit    = trits[2];
        topTrit     = trits[3];

        rightOffset     = offsets[0];
        bottomOffset    = offsets[1];
        leftOffset      = offsets[2];
        topOffset       = offsets[3];

        List<Vector2> vertices = new List<Vector2>();
        List<Vector2> uvs = new List<Vector2>();

        Vector3 topRight    = (Vector3.right + Vector3.up) * .5f;
        Vector3 bottomRight = topRight + Vector3.down;
        Vector3 bottomLeft  = bottomRight + Vector3.left;
        Vector3 topLeft    = bottomLeft + Vector3.up;

        Vector3 topMid      = topLeft       + topOffset     * (topRight     - topLeft);
        Vector3 rightMid    = topRight      + rightOffset   * (bottomRight  - topRight);
        Vector3 bottomMid   = bottomRight   + bottomOffset  * (bottomLeft   - bottomRight);
        Vector3 leftMid     = topLeft       + leftOffset    * (bottomLeft   - topLeft);

        // Square
        vertices.Add(topRight);

        ManageRightEdge(rightMid, vertices);

        vertices.Add(bottomRight);
        
        ManageBottomEdge(bottomMid, vertices);

        vertices.Add(bottomLeft);

        ManageLeftEdge(leftMid, vertices);

        vertices.Add(topLeft);

        ManageTopEdge(topMid, vertices);

        for (int i = 0; i < vertices.Count; i++)
            uvs.Add(vertices[i] + Vector2.one / 2);

        MeshTriangulator triangulator = new MeshTriangulator(vertices.ToArray());
        int[] triangles = triangulator.Triangulate();

        Mesh mesh = new Mesh();

        List<Vector3> v3Vertices = new List<Vector3>();

        foreach (Vector2 vertex in vertices)
            v3Vertices.Add(vertex);      

        mesh.vertices = v3Vertices.ToArray();
        mesh.triangles = triangles;
        mesh.uv = uvs.ToArray();

        mesh.RecalculateBounds();
        mesh.RecalculateNormals();

        renderer.GetComponent<MeshFilter>().mesh = mesh;

        // Generate the outline
        if (outline == null)
            outline = GetComponentInChildren<PuzzlePieceOutline>();

        outline.Generate(vertices.ToArray(), thickness);
    }

    public void ConfigureMaterial(Vector2 tiling, Vector2 offset)
    {
        renderer.material.SetVector("_Tiling", tiling);
        renderer.material.SetVector("_Offset", offset);

        // Generate the outline
        if (outline == null)
            outline = GetComponentInChildren<PuzzlePieceOutline>();

    }

    private void ManageRightEdge(Vector3 rightMid, List<Vector2> vertices)
    {
        if (rightTrit == 0)
            return;

        Vector3[] edgeVertices = GetEdgeVertices(rightTrit);
        Vector3[] rotatedEdgeVertices = RotateVertices(edgeVertices, -90);

        for (int i = 0; i < edgeVertices.Length; i++)
        {
            Vector3 point = rotatedEdgeVertices[i] * jigShape.Scale + rightMid;
            vertices.Add(point);
        }
    }

    private Vector3[] RotateVertices(Vector3[] vertices, float angle)
    {
        for (int i = 0; i < vertices.Length; i++)
            vertices[i] = Quaternion.Euler(0, 0, angle) * vertices[i];

        return vertices;
    }

    private void ManageBottomEdge(Vector3 bottomMid, List<Vector2> vertices)
    {
        if (bottomTrit == 0)
            return;

        Vector3[] edgeVertices = GetEdgeVertices(bottomTrit);

        for (int i = 0; i < edgeVertices.Length; i++)
        {
            Vector3 sample = edgeVertices[i];
            Vector3 rotatedSample = Quaternion.Euler(0, 0, -180) * sample;
            Vector3 point = rotatedSample * jigShape.Scale + bottomMid;

            vertices.Add(point);
        }
    }

    private void ManageLeftEdge(Vector3 leftMid, List<Vector2> vertices)
    {
        if (leftTrit == 0)
            return;

        Vector3[] edgeVertices = GetEdgeVertices(leftTrit);

        for (int i = 0; i < edgeVertices.Length; i++)
        {
            Vector3 sample = edgeVertices[i];
            Vector3 rotatedSample = Quaternion.Euler(0, 0, -270) * sample;
            Vector3 point = rotatedSample * jigShape.Scale + leftMid;

            vertices.Add(point);
        }
    }

    private void ManageTopEdge(Vector3 topMid, List<Vector2> vertices)
    {
        if (topTrit == 0)
            return;

        Vector3[] edgeVertices = GetEdgeVertices(topTrit);

        for (int i = 0; i < edgeVertices.Length; i++)
        {
            Vector3 sample = edgeVertices[i];
            Vector3 point = sample * jigShape.Scale + topMid;
            vertices.Add(point);
        }
    }

    private Vector3[] GetEdgeVertices(int trit)
    {
        SampleCollection sampleCollection = new SampleCollection();
        List<Vector3> vertices = new List<Vector3>();

        switch (trit)
        {
            case 1:
                // Knob
                jigShape.Knob.GetSamples(sampleCollection);

                for (int i = 0; i < sampleCollection.samples.Length; i++)
                    vertices.Add(sampleCollection.samples[i].position);                

                return vertices.ToArray();

            case 2:
                // Hole
                jigShape.Hole.GetSamples(sampleCollection);

                for (int i = 0; i < sampleCollection.samples.Length; i++)
                    vertices.Add(sampleCollection.samples[i].position);

                return vertices.ToArray();

            default:
                return null;
        }
    }

    public int[] GetTrits() => new int[] { rightTrit, bottomTrit, leftTrit, topTrit };
    public float[] GetOffsets() => new float[] { rightOffset, bottomOffset, leftOffset, topOffset };
}
