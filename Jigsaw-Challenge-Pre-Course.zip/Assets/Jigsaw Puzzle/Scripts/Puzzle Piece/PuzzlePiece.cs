using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using Random = UnityEngine.Random;

[RequireComponent(typeof(PuzzlePieceGenerator))]
public class PuzzlePiece : MonoBehaviour, IComparable<PuzzlePiece>
{
    [Header(" Components ")]
    [SerializeField] private Renderer[] shineables; 
    private PuzzlePieceGenerator generator;

    [Header(" Movement ")]
    [SerializeField] private float moveLerp;
    private Vector3 startMovePos;

    [Header(" Validation ")]
    private Vector3 correctPosition;
    public bool IsValid { get; private set; }

    [Header(" Neigbors ")]
    private PuzzlePiece[] neighbors;
    public Transform Group { get; set; }

    [Header(" Actions ")]
    public static Action onValidate;
    public static Action onStartedMoving;
    public static Action onPlaced;
    public static Action onDropped;

    private void Awake()
    {
        generator = GetComponent<PuzzlePieceGenerator>();
    }

    [NaughtyAttributes.Button]
    public void AutoPlace()
    {
        transform.position = correctPosition;
        CheckForValidation();
    }

    public void SetScale(float scale)
    {
        transform.localScale = Vector2.one * scale;
        generator.SetOutlineThickness(scale / Constants.pieceOutlineThicknessMultiplier);
    }

    public void SetNeighbors(params PuzzlePiece[] puzzlePieces)
    {
        neighbors = puzzlePieces;
    }

    public void StoreCorrectPosition(Vector3 correctPosition)
    {
        this.correctPosition = correctPosition;
    }

    public void ConfigureMaterial(Vector2 tiling, Vector2 offset)
    {
        generator.ConfigureMaterial(tiling, offset);
    }

    public void SetOutlineAlpha(float alpha)
    {
        generator.SetOutlineAlpha(alpha);
    }

    public void StartMoving()
    {
        if (IsValid)
            return;

        // Move it slightly up so that it's visible under the finger
        if (Group == null)
            startMovePos = transform.position;
        else
            startMovePos = Group.position;

        onStartedMoving?.Invoke();
    }

    public void Move(Vector3 movementDelta)
    {
        if (IsValid)
            return;

        Vector3 targetPos = startMovePos + movementDelta;

        if(Group == null)
            transform.position = Vector3.Lerp(transform.position, targetPos, Time.deltaTime * 60 * .3f);
        else
            Group.position = Vector3.Lerp(Group.position, targetPos, Time.deltaTime * 60 * .3f);
    }

    public void StopMoving()
    {
        if (IsValid)
            return;

        bool isValid = CheckForValidation();

        if (isValid)
            onPlaced?.Invoke();

        // We need to check for neighbors for all the pieces of that group, one by one
        if (!isValid)
        {
            if (Group == null)
            {
                if (CheckForNeighbors())
                    onPlaced?.Invoke();
                else
                    onDropped?.Invoke();
            }
            else
            {
                for (int i = 0; i < Group.childCount; i++)
                {
                    PuzzlePiece piece = Group.GetChild(i).GetComponent<PuzzlePiece>();

                    // If one of the pieces did find some neighbors, break
                    if (piece.CheckForNeighbors())
                    {
                        onPlaced?.Invoke();
                        return;
                    }
                }

                onDropped?.Invoke();
            }
        }
    }

    private bool CheckForValidation()
    {
        if (IsCloseToCorrectPos() && HasCloseToNullRotation())
        {
            Validate();
            return true;
        }

        return false;
    }

    private bool IsCloseToCorrectPos()
    {
        Vector3 correctedPosition = transform.position.With(z: correctPosition.z);
        return Vector3.Distance(correctedPosition, correctPosition) < GetMinValidDistance();
    }

    private float GetMinValidDistance()
    {
        return Mathf.Max(transform.localScale.x / 5, .05f);
    }

    private bool HasCloseToNullRotation()
    {
        return Vector3.Angle(Vector3.right, transform.right) < 10;
    }

    private void Validate(bool isRecursive = true)
    {
        IsValid = true;

        Shine();

        // Move it back to 0 along z
        correctPosition.z = 0;

        transform.position = correctPosition;
        transform.rotation = Quaternion.identity;

        onValidate?.Invoke();

        if (!isRecursive)
            return;

        // Also validate all the pieces of that group
        if (Group == null)
            return;

        foreach(Transform piece in Group)
        {
            if (piece == transform)
                continue;

            piece.GetComponent<PuzzlePiece>().Validate(false);
        }

    }

    private bool CheckForNeighbors()
    {
        // RULE : All pieces inside of a group should have a local rotation of "identity"


        for (int i = 0; i < neighbors.Length; i++)
        {
            if (neighbors[i] == null)
                continue;

            if (neighbors[i].IsValid)
                continue;

            Vector3 correctLocalPosition = Quaternion.Euler(0, 0, -90 * i) * Vector3.right * transform.localScale.x;
            correctLocalPosition.z = neighbors[i].transform.position.z;

            // Add a way to also check the rotations
            // Two pieces should have the same rotation
            // Or at least close enough

            // Rotate the correct local position
            // Seems like this is working
            correctLocalPosition = transform.rotation * correctLocalPosition;

            Vector3 correctWorldPosition = transform.position + correctLocalPosition;            

            // Rotation should be the first barrier I think cause it's easier to debug ?
            if (Vector3.Angle(transform.right, neighbors[i].transform.right) > 10)
                continue;

            if(Vector3.Distance((Vector2)neighbors[i].transform.position, (Vector2)correctWorldPosition) < GetMinValidDistance())
            {
                // If the neighbor already belongs to the group, no need to check it again
                if (Group != null && neighbors[i].Group == Group)
                    continue;

                // Check if this piece is in a group, & also the other one
                if(Group == null && neighbors[i].Group == null)
                {
                    neighbors[i].transform.position = correctWorldPosition;

                    // Both pieces do not belong to a group, let's create one !
                    GameObject pieceGroup = new GameObject("Piece Group " + Random.Range(100, 200));
                    pieceGroup.transform.position = transform.position;
                    pieceGroup.transform.SetParent(transform.parent);

                    pieceGroup.transform.rotation = transform.rotation;

                    transform.SetParent(pieceGroup.transform);
                    neighbors[i].transform.SetParent(pieceGroup.transform);
                    
                    transform.localRotation = Quaternion.identity;
                    neighbors[i].transform.localRotation = Quaternion.identity;

                    Group = pieceGroup.transform;
                    neighbors[i].Group = Group;
                }                

                // This piece in a group, other not
                else if(Group != null && neighbors[i].Group == null)
                {
                    neighbors[i].transform.position = correctWorldPosition;
                    neighbors[i].transform.rotation = transform.rotation;

                    neighbors[i].Group = Group;
                    neighbors[i].transform.SetParent(Group);
                }

                // This piece not in group, other yes
                else if(Group == null && neighbors[i].Group != null)
                {
                    Group = neighbors[i].Group;
                    transform.SetParent(Group);

                    transform.rotation = neighbors[i].transform.rotation;

                    // Recalculate the correct position for this piece instead of the neighbor ?
                    Vector3 thisCorrectWorldPosition = neighbors[i].transform.position + 
                        Quaternion.Euler(0, 0, -90 * (i + 2)) * neighbors[i].transform.right * transform.localScale.x;

                    transform.position = thisCorrectWorldPosition;
                }

                // Both pieces belong to different groups
                else if(Group != null && neighbors[i].Group != null && Group != neighbors[i].Group)
                {
                    // Recalculate the correct position for this piece instead of the neighbor ?
                    Vector3 thisCorrectWorldPosition = neighbors[i].transform.position +
                        Quaternion.Euler(0, 0, -90 * (i + 2)) * neighbors[i].transform.right * transform.localScale.x;

                    // This works for one piece
                    Vector3 moveVector = thisCorrectWorldPosition - transform.position;

                    Group.position += moveVector;

                    // Now lets rotate around the piece we just moved
                    Vector3 rotationCenter = transform.position;
                    float angle = Vector3.SignedAngle(transform.right, neighbors[i].transform.right, Vector3.forward);

                    Group.RotateAround(rotationCenter, Vector3.forward, angle);

                    while (Group.childCount > 0)
                    {
                        Transform piece = Group.GetChild(0);
                        piece.SetParent(neighbors[i].Group);
                    }

                    // Destroy this group
                    DestroyImmediate(Group.gameObject);

                    foreach (Transform piece in neighbors[i].Group)
                        piece.GetComponent<PuzzlePiece>().Group = piece.parent;
                }

                return true;
            }                
        }

        return false;
    }

    public int CompareTo(PuzzlePiece otherPiece)
    {
        return transform.position.z.CompareTo(otherPiece.transform.position.z);
    }

    public void Shine()
    {
        foreach (Renderer renderer in shineables)
            LeanTween.value(renderer.gameObject, 0, 1, .5f).setOnUpdate((value) => renderer.material.SetFloat("_ShinePercent", value));        
    }
}
