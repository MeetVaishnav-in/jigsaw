using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

using Random = UnityEngine.Random;

public class PhotoManager : MonoBehaviour
{
	public static PhotoManager instance;

	[Header(" Elements ")]
	[SerializeField] private Material watercolorMaterial;

	[Header(" Settings ")]
	[SerializeField] private int pictureSize;
	[SerializeField] private Texture2D lastPhoto;

	public static Action<Texture2D> onPhotoTaken;
	private bool pictureTaken;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);

		GameManager.onGameStateChanged			+= GameStateChangedCallback;
		MuseumZoomedPanel.onReplayButtonPressed += ReplayImage;
    }

    private void OnDestroy()
    {
		GameManager.onGameStateChanged			-= GameStateChangedCallback;
		MuseumZoomedPanel.onReplayButtonPressed -= ReplayImage;
    }

    private void GameStateChangedCallback(GameState gameState)
    {
		switch(gameState)
        {
			case GameState.Menu:
				pictureTaken = false;
				break;
        }
    }



	public void TakePictureButtonCallback()
	{
		if (!pictureTaken)
			TakePicture(pictureSize);
    }


	private void TakePicture(int maxSize)
	{
		NativeCamera.Permission permission = NativeCamera.TakePicture((path) =>
		{
			if (path != null)
			{
				// Create a Texture2D from the captured image
				Texture2D texture = NativeCamera.LoadImageAtPath(path, maxSize, false);
				if (texture == null)
				{
					Debug.Log("Couldn't load texture from " + path);
					return;
				}

				// Square out the texture
				// Later on, I can propose the player to crop it / Zoom it
				texture = SquareTexture(texture);

				StartCoroutine(ProcessTextureCoroutine(texture));
			}
		}, maxSize);
	}

	IEnumerator ProcessTextureCoroutine(Texture2D texture)
    {
		yield return null;

		RenderTexture rt = new RenderTexture(texture.width, texture.height, 0, RenderTextureFormat.ARGB32, texture.mipmapCount);
		rt.useMipMap = true;

		// Once the texture is squared, apply the "Watercolor" effect
		Graphics.Blit(texture, rt, watercolorMaterial);

		RenderTexture.active = rt;

		// Create a new Texture2D and read the pixels from the active render texture
		Texture2D processedTexture = new Texture2D(rt.width, rt.height);
		processedTexture.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0);
		processedTexture.Apply();

		// Reset the active render texture
		RenderTexture.active = null;

		processedTexture.name = "Last Photo";

		// Store the last photo to save it later on
		lastPhoto = processedTexture;

		pictureTaken = true;

		onPhotoTaken?.Invoke(processedTexture);
	}


	private void ReplayImage(Texture2D texToReplay)
	{
		lastPhoto = texToReplay;
		onPhotoTaken?.Invoke(texToReplay);
	}

	private Texture2D SquareTexture(Texture2D tex)
    {
		// If already squared, don't touch it
		if (tex.width == tex.height)
        {
			Debug.Log("Already squared");
			return tex;
        }

		// Grab the smallest size for the cropping / squaring
		int minSize = tex.width > tex.height ? tex.height : tex.width;

		Color[] pixels = tex.GetPixels(0, 0, minSize, minSize);

		Texture2D croppedTex = new Texture2D(minSize, minSize);
		croppedTex.SetPixels(pixels);
		croppedTex.Apply();

		return croppedTex;
    }

	public Texture2D GetLastPhoto() => lastPhoto;
}
