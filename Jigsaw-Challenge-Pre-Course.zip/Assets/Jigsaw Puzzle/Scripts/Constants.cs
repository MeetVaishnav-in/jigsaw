using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Constants
{
    [Header(" General ")]
    public const float puzzleWorldSize = 4f;

    public const float minKnobOffset = .35f;
    public const float maxKnobOffset = .65f;

    public const float pieceOutlineThicknessMultiplier = 50f;

    [Header(" Placement ")]
    public const float goldenAngle = 137.51f;

    [Header(" Control ")]
    public const float pieceDetectionRadiusMultiplier = 1.8f;
    public const float piecesZOffset = 0.001f;

    public static float GetRandomKnobOffset() => Random.Range(minKnobOffset, maxKnobOffset);
}