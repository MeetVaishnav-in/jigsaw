using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    [Header(" Settings ")]
    private GameState gameState;

    [Header(" Actions ")]
    public static Action<GameState> onGameStateChanged;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);

        Puzzle.onPuzzleCompleted += PuzzleCompleteCallback;
    }

    private void OnDestroy()
    {
        Puzzle.onPuzzleCompleted -= PuzzleCompleteCallback;
    }


    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 60;

        SetMenu();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void SetMenu()
    {
        SetGameState(GameState.Menu);
    }

    private void SetGame()
    {
        SetGameState(GameState.Game);
    }

    private void SetGameState(GameState gameState)
    {
        this.gameState = gameState;
        onGameStateChanged?.Invoke(gameState);
    }

    public GameState GetGameState()
    {
        return gameState;
    }

    public bool IsPuzzleCompleteState() => gameState == GameState.PuzzleCompleted;

    public void SetGameState()
    {
        SetGame();
    }

    public void SetPuzzleComplete()
    {
        SetGameState(GameState.PuzzleCompleted);
    }

    public bool IsGameState()
    {
        return gameState == GameState.Game;
    }

    private void PuzzleCompleteCallback()
    {
        SetPuzzleComplete();
    }

    public bool IsPlaying()
    {
        return gameState == GameState.Game || gameState == GameState.PuzzleCompleted;
    }
}
