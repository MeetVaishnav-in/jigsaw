using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;

public class TimerManager : MonoBehaviour
{
    public static TimerManager instance;

    [Header(" Elements ")]
    [SerializeField] private TextMeshProUGUI timerText;
    private int timerSeconds;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);

        GameManager.onGameStateChanged += GameStateChangedCallback;
    }



    private void OnDestroy()
    {
        GameManager.onGameStateChanged -= GameStateChangedCallback;
    }

    // Start is called before the first frame update
    void Start()
    {
        timerText.text = "Timer";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void GameStateChangedCallback(GameState gameState)
    {
        switch(gameState)
        {
            case GameState.Game:
                StartTimer();
                break;

            case GameState.PuzzleCompleted:
                StopTimer();
                break;
        }
    }

    public void StartTimer()
    {
        timerSeconds = 0;
        timerText.text = "00:00";

        InvokeRepeating("UpdateTimer", 1, 1);
    }

    private void UpdateTimer()
    {
        timerSeconds++;
        timerText.text = GetTimerString();
    }

    public void StopTimer()
    {
        CancelInvoke("UpdateTimer");
    }

    public int GetTimerSeconds()
    {
        return timerSeconds;
    }

    public string GetTimerString()
    {
        return TimeSpan.FromSeconds(timerSeconds).ToString().Substring(3);
    }
}
