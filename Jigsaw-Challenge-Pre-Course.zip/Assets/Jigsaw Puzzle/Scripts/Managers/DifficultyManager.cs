using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class DifficultyManager : MonoBehaviour
{
    public static DifficultyManager instance;

    [Header(" Elements ")]
    [SerializeField] private RawImage photoImage;

    [SerializeField] private Slider difficultySlider;
    [SerializeField] private Image sliderFillImage;
    [SerializeField] private TextMeshProUGUI difficultyText;

    [SerializeField] private Toggle rotationToggle;

    [Header(" Settings ")]
    [Tooltip("We need 4 colors for now")]
    [SerializeField] private Color[] colors;
    [SerializeField] private string[] difficultyLabels;
    [SerializeField] private int[] gridSizes;

    [Header(" Actions ")]
    public static Action<int> onDifficultySelected;

    private void Awake()
    {
        if (instance == null)
            instance = this;
        else
            Destroy(gameObject);

        difficultySlider.onValueChanged.AddListener(UpdateColor);
        difficultySlider.onValueChanged.AddListener(UpdateText);

        PhotoManager.onPhotoTaken += PhotoTakenCallback;
    }

    private void OnDestroy()
    {
        PhotoManager.onPhotoTaken -= PhotoTakenCallback;        
    }

    private void Start()
    {
        difficultySlider.value = difficultySlider.maxValue / 2;
    }


    public void StartedEditingSlider()
    {
        LeanTween.cancel(difficultySlider.gameObject);
    }

    public void FinishedEditingSlider()
    {
        int closestInt = Mathf.RoundToInt(difficultySlider.value);

        LeanTween.value(difficultySlider.gameObject, difficultySlider.value, closestInt, .25f).
            setOnUpdate((value) => difficultySlider.value = value);
    }

    private void UpdateColor(float sliderValue)
    {
        int floorInt = Mathf.FloorToInt(difficultySlider.value);
        int ceilInt = Mathf.CeilToInt(difficultySlider.value);

        float percent = Mathf.InverseLerp(floorInt, ceilInt, sliderValue);

        Color targetColor = Color.Lerp(colors[floorInt], colors[ceilInt], percent);

        sliderFillImage.color = targetColor;
        difficultyText.color = targetColor;
    }

    private void UpdateText(float sliderValue)
    {
        int closestDifficulty = Mathf.RoundToInt(sliderValue);
        difficultyText.text = difficultyLabels[closestDifficulty];
    }

    public void PlayButtonCallback()
    {
        // Set the Game State
        GameManager.instance.SetGameState();

        // Generate the Puzzle
        onDifficultySelected?.Invoke(GetGridSize());
    }

    private void PhotoTakenCallback(Texture2D photoTex)
    {
        photoImage.texture = photoTex;
    }

    public int GetDifficultyLevel() => Mathf.RoundToInt(difficultySlider.value);
    public int GetGridSize() => gridSizes[GetDifficultyLevel()];

    public bool IsRotationOn()
    {
        return rotationToggle.isOn;
    }
}
