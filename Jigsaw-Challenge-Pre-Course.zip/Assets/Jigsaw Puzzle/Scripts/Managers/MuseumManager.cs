using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MuseumManager : MonoBehaviour
{
    [Header(" Elements ")]
    [SerializeField] private PuzzleMuseumContainer photoPrefab;
    [SerializeField] private Transform photosParent;

    [Header(" Settings ")]
    int textureCount;
    private const string textureCountKey = "TextureCount";

    private void Awake()
    {
        LoadData();
        SetupMuseum();

        Puzzle.onPuzzleCompleted += PuzzleCompletedCallback;
    }

    private void OnDestroy()
    {
        Puzzle.onPuzzleCompleted -= PuzzleCompletedCallback;
    }

    private IEnumerator Start()
    {
        yield return null;

        ConfigureGridLayout();
    }

    private void SetupMuseum()
    {
        while(photosParent.childCount > 0)
        {
            Transform t = photosParent.GetChild(0);
            t.SetParent(null);
            Destroy(t.gameObject);
        }

        for (int i = 0; i < textureCount; i++)
        {
            Texture2D tex = ImageUtilities.GetSavedTexture("Texture_" + i);
            Sprite sprite = ImageUtilities.SpriteFromTexture(tex);
            string timeString = GetTextureTime(i);

            PuzzleMuseumContainer puzzleMuseumInstance = Instantiate(photoPrefab, photosParent);
            puzzleMuseumInstance.Configure(sprite, timeString);
        }
    }

    private void PuzzleCompletedCallback()
    {
        // Grab the texture
        Texture2D lastPuzzle = PhotoManager.instance.GetLastPhoto();
        ImageUtilities.SaveTexture(lastPuzzle, "Texture_" + textureCount);

        textureCount++;
        SaveData();

        // Add pic to museum
        Sprite sprite = ImageUtilities.SpriteFromTexture(lastPuzzle);
        string timeString = TimerManager.instance.GetTimerString();

        SaveTextureTime(textureCount - 1, timeString);
        
        PuzzleMuseumContainer puzzleMuseumInstance = Instantiate(photoPrefab, photosParent);
        puzzleMuseumInstance.Configure(sprite, timeString);
    }

    private void LoadData()
    {
        textureCount = PlayerPrefs.GetInt(textureCountKey);
    }

    private void SaveData()
    {
        PlayerPrefs.SetInt(textureCountKey, textureCount);
    }

    private string GetTextureName(int index)
    {
        return "Texture_" + index;
    }

    private string GetTextureTime(int index)
    {
        return PlayerPrefs.GetString("TextureTime" + index);
    }

    private void SaveTextureTime(int index, string time)
    {
        PlayerPrefs.SetString("TextureTime" + index, time);
    }

    private void ConfigureGridLayout()
    {
        float screenWidth = Screen.width;
        Canvas canvas = photosParent.GetComponentInParent<Canvas>();

        screenWidth = (float)(canvas.pixelRect.width) / canvas.transform.lossyScale.x;        

        GridLayoutGroup gridLayout = photosParent.GetComponent<GridLayoutGroup>();

        screenWidth = photosParent.GetComponent<RectTransform>().rect.width;

        float cellSize = screenWidth / 2.5f;
        float spaceLeftAfterCells = screenWidth - (2 * cellSize);

        float padding = spaceLeftAfterCells / 3;

        gridLayout.padding.left = (int)padding;
        gridLayout.padding.right = (int)padding;

        gridLayout.cellSize = Vector2.one * cellSize;

        gridLayout.spacing = Vector2.one * padding;
    }
}
