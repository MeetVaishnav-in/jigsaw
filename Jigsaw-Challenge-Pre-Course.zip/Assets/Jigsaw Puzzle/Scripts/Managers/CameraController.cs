using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraController : MonoBehaviour
{
    private new Camera camera;

    [Header(" Movement Settings ")]
    [SerializeField] private float moveSpeed;
    private Vector3 initialPosition;

    [Header(" Zoom Settings ")]
    [SerializeField] private Vector2 minMaxOrthoSize;
    [SerializeField] private float zoomMultiplier;
    [SerializeField] [Range(1f, 5f)] private float zoomSpeed;
    private float clickedOrthoSize;

    Vector2 touch0ClickedPos;
    Vector3 zoomInitialPos;
    Vector3 zoomCenter;

    private void Awake()
    {
        camera = GetComponent<Camera>();
        clickedOrthoSize = camera.orthographicSize;

        initialPosition = transform.position;

        InputManager.onBeganTouch   += BeganTouchCallback;
        InputManager.onTouching     += TouchingCallback;
        InputManager.onEndedTouch   += EndedTouchCallback;

        InputManager.onDoubleTouchBegan += DoubleTouchBeganCallback;
        InputManager.onDoubleTouching   += DoubleTouchingCallback;
    }

    private void OnDestroy()
    {
        InputManager.onBeganTouch   -= BeganTouchCallback;
        InputManager.onTouching     -= TouchingCallback;
        InputManager.onEndedTouch   -= EndedTouchCallback;

        InputManager.onDoubleTouchBegan -= DoubleTouchBeganCallback;
        InputManager.onDoubleTouching   -= DoubleTouchingCallback;
    }

    private void BeganTouchCallback(Vector2 touchPos)
    {
        touch0ClickedPos = touchPos;
    }

    private void TouchingCallback(Vector2 touchPos)
    {
        Vector3 moveDelta = -(touchPos - touch0ClickedPos) / Screen.width;

        // Take the last ortho size into account
        // The smaller it is, the more zoomed in it becomes
        // The slower we should move
        moveDelta *= camera.orthographicSize;

        Vector3 targetPos = initialPosition + moveDelta * moveSpeed;
        transform.position = targetPos;
    }

    private void EndedTouchCallback(Vector2 touchPos)
    {
        initialPosition = transform.position;
    }

    private void DoubleTouchBeganCallback(Vector2 touch0ClickedPos, Vector2 touch1ClickedPos)
    {
        clickedOrthoSize = camera.orthographicSize;

        this.touch0ClickedPos = touch0ClickedPos;

        zoomInitialPos = transform.position;

        // Calculate the Zoom center
        zoomCenter =(CameraUtils.GetWorldPosition(touch0ClickedPos) + CameraUtils.GetWorldPosition(touch1ClickedPos)) / 2;
        zoomCenter.z = -10;
    }

    private void DoubleTouchingCallback(float magnitude)
    {
        SetOrthoSize(magnitude);
        MoveTowardsZoomCenter(magnitude);
    }

    private void SetOrthoSize(float distanceDelta)
    {
        float targetOrthoSize = clickedOrthoSize - distanceDelta * zoomMultiplier;
        targetOrthoSize = Mathf.Clamp(targetOrthoSize, minMaxOrthoSize.x, minMaxOrthoSize.y);

        camera.orthographicSize = Mathf.Lerp(camera.orthographicSize, targetOrthoSize, Time.deltaTime * 60 * .3f);
    }

    private void MoveTowardsZoomCenter(float magnitude)
    {
        float percent = Mathf.InverseLerp(minMaxOrthoSize.x, minMaxOrthoSize.y, clickedOrthoSize - camera.orthographicSize);
        percent *= zoomSpeed;

        Vector3 targetPosition = Vector3.Lerp(zoomInitialPos, zoomCenter, percent);
        transform.position = targetPosition;

        initialPosition = transform.position;        

    }
}
