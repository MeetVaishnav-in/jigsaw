using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    [Header(" Panels ")]
    [SerializeField] private GameObject menuPanel;
    [SerializeField] private GameObject gamePanel;
    [SerializeField] private GameObject museumPanel;
    [SerializeField] private GameObject difficultySelection;
    [SerializeField] private GameObject puzzleCompletePanel;
    private List<GameObject> panels = new List<GameObject>();

    private void Awake()
    {
        StorePanels();

        PhotoManager.onPhotoTaken               += PhotoTakenCallback;
        GameManager.onGameStateChanged          += GameStateChangedCallback;
        DifficultyManager.onDifficultySelected  += DifficultySelectedCallback;
    }



    private void OnDestroy()
    {
        PhotoManager.onPhotoTaken               -= PhotoTakenCallback;
        GameManager.onGameStateChanged          -= GameStateChangedCallback;
        DifficultyManager.onDifficultySelected  -= DifficultySelectedCallback;
    }

    private void StorePanels()
    {
        panels.Add(menuPanel);
        panels.Add(gamePanel);
        panels.Add(museumPanel);
        panels.Add(difficultySelection);
        panels.Add(puzzleCompletePanel);
    }


    private void GameStateChangedCallback(GameState gameState)
    {
        switch(gameState)
        {
            case GameState.Menu:
                SetMenu();
                break;

            case GameState.PuzzleCompleted:
                SetPuzzleComplete();
                break;
        }
    }

    // Start is called before the first frame update
    void Start() => GameManager.instance.SetMenu();

    public void SetMenu()   => ShowPanel(menuPanel);
    public void SetGame()   => ShowPanel(gamePanel);
    public void SetMuseum() => ShowPanel(museumPanel);

    public void SetPuzzleComplete()         => ShowPanel(puzzleCompletePanel);
    private void SetDifficultySelection()   => ShowPanel(difficultySelection);

    public void ShowPanel(GameObject panel)
    {
        for (int i = 0; i < panels.Count; i++)
            panels[i].SetActive(panels[i] == panel);        
    }

    private void PhotoTakenCallback(Texture2D photo) => SetDifficultySelection();

    public void PuzzleCompleteButtonCallback() => UnityEngine.SceneManagement.SceneManager.LoadScene(0);

    public void BackFromDifficulty() => GameManager.instance.SetMenu();

    private void DifficultySelectedCallback(int gridSize) => SetGame();
}
