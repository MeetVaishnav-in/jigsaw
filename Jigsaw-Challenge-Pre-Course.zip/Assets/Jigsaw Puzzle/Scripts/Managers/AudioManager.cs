using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    [Header(" Sources ")]
    [SerializeField] private AudioSource pickSound;
    [SerializeField] private AudioSource placeSound;
    [SerializeField] private AudioSource dropSound;

    private void Awake()
    {
        PuzzlePiece.onStartedMoving += PlayPickSound;
        PuzzlePiece.onPlaced        += PlayPlaceSound;
        PuzzlePiece.onDropped       += PlayDropSound;
    }

    private void OnDestroy()
    {
        PuzzlePiece.onStartedMoving -= PlayPickSound;
        PuzzlePiece.onPlaced        -= PlayPlaceSound;
        PuzzlePiece.onDropped       -= PlayDropSound;
    }

    private void PlayPickSound()    => PlaySource(pickSound, true);
    private void PlayPlaceSound()   => PlaySource(placeSound, true);
    private void PlayDropSound()    => PlaySource(dropSound, true);

    private void PlaySource(AudioSource source, bool randomPitch = false)
    {
        if (!randomPitch)
            source.pitch = 1;
        else
            source.pitch = Random.Range(.9f, 1f);

        PlaySource(source);
    }

    private void PlaySource(AudioSource source) => source.Play();
}
