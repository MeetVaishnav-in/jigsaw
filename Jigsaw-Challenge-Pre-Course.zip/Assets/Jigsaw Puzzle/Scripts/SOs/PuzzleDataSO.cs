using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Puzzle Data", menuName = "Scriptable Objects/Puzzle Data")]
public class PuzzleDataSO : ScriptableObject
{
    //[field: SerializeField] public int GridSize { get; private set; }
    [field: SerializeField] public float ZOffset { get; private set; }
    [field: SerializeField] public PuzzlePiece PiecePrefab { get; private set; }
}
