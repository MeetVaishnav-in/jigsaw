using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Dreamteck.Splines;

[CreateAssetMenu(fileName = "JigShape", menuName = "Scriptable Objects/JigShape", order = 0)]
public class JigShapeSO : ScriptableObject
{
    [field: SerializeField] public SplineComputer Hole { get; private set; }
    [field: SerializeField] public SplineComputer Knob { get; private set; }

    [field: SerializeField] public float Scale { get; private set; }
}
