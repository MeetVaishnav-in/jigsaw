using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObsoletePuzzlePiece : MonoBehaviour
{
    [Header(" Components ")]
    [SerializeField] private Renderer renderer;

    [Header(" Settings ")]
    [SerializeField] private Vector2 tiling;
    [SerializeField] private Vector2 offset;

    [Header(" References ")]
    private const string tilingRef = "_Tiling";
    private const string offsetRef = "_Offset";

    // Start is called before the first frame update
    void Start()
    {
        renderer.material.SetVector(tilingRef, tiling);
        renderer.material.SetVector(offsetRef, offset);

        renderer.material.SetFloat("_Angle", transform.localEulerAngles.y);
    }

}
