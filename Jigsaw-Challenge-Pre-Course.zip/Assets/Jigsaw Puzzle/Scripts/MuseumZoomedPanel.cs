using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class MuseumZoomedPanel : MonoBehaviour
{
    [Header(" Elements ")]
    [SerializeField] private GameObject zoomedPanel;
    [SerializeField] private Image zoomedImage;


    [Header(" Actions ")]
    public static Action<Texture2D> onReplayButtonPressed;

    private void Awake()
    {
        PuzzleMuseumContainer.onPointerDown += ShowZoomPanel;
    }

    private void OnDestroy()
    {
        PuzzleMuseumContainer.onPointerDown -= ShowZoomPanel;
    }

    // Start is called before the first frame update
    void Start()
    {
        zoomedPanel.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void ShowZoomPanel(Sprite sprite)
    {
        zoomedImage.sprite = sprite;

        // Display panel
        zoomedPanel.SetActive(true);
    }

    public void HidePanel()
    {
        zoomedPanel.SetActive(false);
    }

    public void ReplayImageButtonCallback()
    {
        onReplayButtonPressed?.Invoke(zoomedImage.sprite.texture);
    }
}
