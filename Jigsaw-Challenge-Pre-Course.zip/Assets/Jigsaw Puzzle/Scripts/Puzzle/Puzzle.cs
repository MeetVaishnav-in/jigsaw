using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puzzle : MonoBehaviour
{
    [Header(" Components ")]
    [SerializeField] private PuzzleGenerator puzzleGenerator;
    [SerializeField] private PuzzleController puzzleController;

    [Header(" Rendering ")]
    [SerializeField] private Material puzzlePieceMaterial;

    [Header(" Data ")]
    [SerializeField] private PuzzleDataSO data;

    [Header(" Actions ")]
    public static Action onPuzzleCompleted;

    private void Awake()
    {
        PhotoManager.onPhotoTaken               += PhotoTakenCallback;
        PuzzlePiece.onValidate                  += PieceValidatedCallback;
        DifficultyManager.onDifficultySelected  += DifficultySelectedCallback;
    }

    private void OnDestroy()
    {
        PhotoManager.onPhotoTaken               -= PhotoTakenCallback;
        PuzzlePiece.onValidate                  -= PieceValidatedCallback;
        DifficultyManager.onDifficultySelected  -= DifficultySelectedCallback;
    }

    private void PhotoTakenCallback(Texture2D photoTex)
    {
        puzzlePieceMaterial.mainTexture = photoTex;
    }

    private void DifficultySelectedCallback(int gridSize)
    {
        puzzleGenerator.Generate(data, gridSize, puzzleController);
    }


    private void PieceValidatedCallback()
    {
        PuzzlePiece[] pieces = puzzleGenerator.GetPieces();

        for (int i = 0; i < pieces.Length; i++)
            if (!pieces[i].IsValid)
                return;

        PuzzleCompleted();
    }

    private void PuzzleCompleted()
    {
        PuzzlePiece[] pieces = puzzleGenerator.GetPieces();

        for (int i = 0; i < pieces.Length; i++)
            pieces[i].SetOutlineAlpha(0);

        onPuzzleCompleted?.Invoke();
    }
}
