using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzleController : MonoBehaviour
{
    [Header(" Elements ")]
    private PuzzleGenerator puzzleGenerator;

    [Header(" Settings ")]
    private float detectionRadius;
    private PuzzlePiece currentPiece;

    [Header(" Control Settings ")]
    private Vector3 clickedPosition;

    [Header(" Rotation Settings ")]
    [SerializeField] private float rotationSpeed;
    private Quaternion pieceStartRotation;

    public void Configure(PuzzleGenerator puzzleGenerator, float pieceSize)
    {
        this.puzzleGenerator = puzzleGenerator;

        detectionRadius = pieceSize / Constants.pieceDetectionRadiusMultiplier;
    }

    public bool MouseDownCallback(Vector3 worldPos)
    {
        // Check for the closest piece within a certain radius
        // I could also have used colliders & raycasts, but is it better performance wise ?
        PuzzlePiece[] pieces = puzzleGenerator.GetPieces();
        currentPiece = GetTopClosestPiece(pieces, worldPos);

        if (currentPiece == null)
            return false;

        ManagePiecesOrder(pieces);

        clickedPosition = worldPos;
        currentPiece.StartMoving();

        return true;
    }

    public void MouseDragCallback(Vector3 worldPos)
    {
        if (currentPiece == null)
            return;

        Vector3 moveVector = worldPos - clickedPosition;
        currentPiece.Move(moveVector);
    }

    public void MouseUpCallback(Vector3 worldPos)
    {
        if (currentPiece == null)
            return;

        currentPiece.StopMoving();
        currentPiece = null;
    }

    public void StartRotatingPiece()
    {
        if (currentPiece == null)
            return;

        if (currentPiece.Group == null)
            pieceStartRotation = currentPiece.transform.rotation;
        else
            pieceStartRotation = currentPiece.Group.rotation;
    }

    public void RotatePiece(float xDelta)
    {
        if (currentPiece == null)
            return;

        float targetZ = xDelta * rotationSpeed;
        Quaternion targetRotation = pieceStartRotation * Quaternion.Euler(0, 0, targetZ);

        // If the piece belongs to a group, we should rotate the group !!!
        if (currentPiece.Group == null)
            currentPiece.transform.rotation = targetRotation;
        else
            currentPiece.Group.rotation = targetRotation;
    }

    private void ManagePiecesOrder(PuzzlePiece[] pieces)
    {
        float highestZ = pieces.Length * Constants.piecesZOffset;
        float currentPieceZ = currentPiece.transform.position.z;

        // Bring forward the selected piece
        currentPiece.transform.position = currentPiece.transform.position.With(z: -highestZ);

        // Check for all of the other pieces, remove .1 from their z
        for (int i = 0; i < pieces.Length; i++)
        {
            // Skip the current piece
            if (pieces[i] == currentPiece)
                continue;

            if (pieces[i].transform.position.z < currentPieceZ)
                pieces[i].transform.position += Vector3.forward * Constants.piecesZOffset;
        }

        // Move all of the pieces that belong to the current piece group too
        if (currentPiece.Group == null)
            return;

        foreach (Transform piece in currentPiece.Group)
            piece.position = piece.position.With(z: -highestZ);
    }

    private PuzzlePiece GetTopClosestPiece(PuzzlePiece[] pieces, Vector3 worldPos)
    {
        List<PuzzlePiece> potentialPieces = new List<PuzzlePiece>();

        // Populate the potential pieces
        for (int i = 0; i < pieces.Length; i++)
        {
            if (pieces[i].IsValid)
                continue;

            Vector3 piecePos = pieces[i].transform.position;
            piecePos.z = worldPos.z;

            float distance = Vector3.Distance(worldPos, piecePos);

            if (distance >= detectionRadius)
                continue;

            potentialPieces.Add(pieces[i]);
        }

        // Sort them
        if (potentialPieces.Count <= 0)
            return null;

        potentialPieces.Sort();

        return potentialPieces[0];
    }
}
