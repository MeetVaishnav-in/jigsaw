using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

using Random = UnityEngine.Random;

public class PuzzleGenerator : MonoBehaviour
{
    [Header(" Elements ")]
    private PuzzleController puzzleController;
    private PuzzlePiece piecePrefab;

    [Header(" Settings ")]
    private Vector2Int gridSize;
    private float gridScale;
    private float pieceZOffset; 

    [Header(" Actions ")]
    public static Action<Vector2Int, float> onPuzzleGenerated;

    // I will need to pass in the texture too here
    // Maybe along with the gridSize

    // We can then deduce the scale taking the cam ortho size into account

    public void Generate(PuzzleDataSO data, int gridSize, PuzzleController puzzleController)
    {
        this.puzzleController = puzzleController;

        gridScale = Constants.puzzleWorldSize / gridSize;
        this.gridSize = Vector2Int.one * gridSize;
        pieceZOffset = data.ZOffset;

        piecePrefab = data.PiecePrefab;

        puzzleController.Configure(this, gridScale);

        GeneratePuzzle();

        onPuzzleGenerated?.Invoke(this.gridSize, gridScale);
    }

    private void GeneratePuzzle()
    {
        Vector3 startPos = Vector2.left * (((float)gridSize.x * gridScale / 2) - (gridScale / 2)) + 
                           Vector2.down * (((float)gridSize.y * gridScale / 2) - (gridScale / 2));
            
        for (int x = 0; x < gridSize.x; x++)
        {
            for (int y = 0; y < gridSize.y; y++)
            {
                // Start from the bottom left
                Vector3 position = startPos + new Vector3(x, y) * gridScale;

                // Each piece is moved along the z axis by .1 to manage sorting later on
                position.z -= GridPosToIndex(x,y) * pieceZOffset;

                Vector3 randomPosition = GetPieceSpiralPosition(GridPosToIndex(x, y), gridScale);
                randomPosition.z = position.z;

                PuzzlePiece piece = Instantiate(piecePrefab, randomPosition, Quaternion.identity, transform);

                // Scale it
                piece.SetScale(gridScale);
                
                if(DifficultyManager.instance.IsRotationOn())
                    piece.transform.rotation = Quaternion.Euler(0, 0, Random.Range(0f, 360f));
                
                piece.StoreCorrectPosition(position);

                Vector2 tiling = new Vector2(1f / gridSize.x, 1f / gridSize.y);
                Vector2 offset = new Vector2((float)x / gridSize.x, (float)y / gridSize.y);

                piece.ConfigureMaterial(tiling, offset);
            }
        }

        // Now that we have instantiated them, configure them
        ConfigurePieces();
    }

    private void ConfigurePieces()
    {
        for (int i = 0; i < transform.childCount; i++)
            ConfigurePiece(transform.GetChild(i).GetComponent<PuzzlePieceGenerator>());        
    }

    private void ConfigurePiece(PuzzlePieceGenerator piece)
    {
        int index = piece.transform.GetSiblingIndex();
        Vector2Int gridPos = IndexToGridPos(index);

        int x = gridPos.x;
        int y = gridPos.y;

        int[] trits = GetTrits(x, y);
        float[] offsets = GetOffsets(x, y);

        piece.Configure(trits, offsets);

        // Here, I can also configure the neighbors ?
        PuzzlePiece rightNeighbor   = IsValidGridPos(x + 1, y) ? transform.GetChild(GridPosToIndex(x + 1, y)).GetComponent<PuzzlePiece>() : null;
        PuzzlePiece bottomNeighbor  = IsValidGridPos(x, y - 1) ? transform.GetChild(GridPosToIndex(x, y - 1)).GetComponent<PuzzlePiece>() : null;
        PuzzlePiece leftNeighbor    = IsValidGridPos(x - 1, y) ? transform.GetChild(GridPosToIndex(x - 1, y)).GetComponent<PuzzlePiece>() : null;
        PuzzlePiece topNeighbor     = IsValidGridPos(x, y + 1) ? transform.GetChild(GridPosToIndex(x, y + 1)).GetComponent<PuzzlePiece>() : null;

        piece.GetComponent<PuzzlePiece>().SetNeighbors(rightNeighbor, bottomNeighbor, leftNeighbor, topNeighbor);
    }

    private Vector2Int IndexToGridPos(int index)
    {
        int x = index / gridSize.y;
        int y = (int)((float)index % gridSize.y);

        return new Vector2Int(x, y);
    }

    private int GridPosToIndex(int x, int y) => y + x * gridSize.y;

    private int[] GetTrits(int x, int y)
    {
        int right, bottom, left, top;
        right = bottom = left = top = 0;

        // If first piece, randomize it
        if(x == 0 && y == 0)
            return new int[] { GetRandomEdge(), 0, 0, GetRandomEdge() };

        if(IsValidGridPos(x, y - 1))
        {
            PuzzlePieceGenerator bottomNeighbor = transform.GetChild(GridPosToIndex(x, y - 1)).GetComponent<PuzzlePieceGenerator>();
            int[] bottomNeighborTrits = bottomNeighbor.GetTrits();

            // Grab the top trit
            int neighborBottomTrit = bottomNeighborTrits[3];

            // Apply the opposite edge knob / hole
            bottom = neighborBottomTrit == 1 ? 2 : 1;
        }


        // Now do the same thing for the left edge
        if(IsValidGridPos(x - 1, y))
        {
            PuzzlePieceGenerator leftNeighbor = transform.GetChild(GridPosToIndex(x - 1, y)).GetComponent<PuzzlePieceGenerator>();
            int[] leftNeighborTrits = leftNeighbor.GetTrits();

            // Grab the right trit
            int neighborRightTrit = leftNeighborTrits[0];

            // Apply the opposite edge knob / hole
            left = neighborRightTrit == 1 ? 2 : 1;
        }


        // Set random right & up if possible
        if (IsValidGridPos(x, y + 1))
            top = GetRandomEdge();

        if (IsValidGridPos(x + 1, y))
            right = GetRandomEdge();

        return new int[] { right, bottom, left, top };
    }

    private float[] GetOffsets(int x, int y)
    {
        float right, bottom, left, top;
        right = bottom = left = top = .5f;

        // If first piece, randomize it
        if (x == 0 && y == 0)
            return new float[] 
            { 
                Constants.GetRandomKnobOffset(), 
                0.5f, 
                0.5f, 
                Constants.GetRandomKnobOffset() 
            };

        if (IsValidGridPos(x, y - 1))
        {
            PuzzlePieceGenerator bottomNeighbor = transform.GetChild(GridPosToIndex(x, y - 1)).GetComponent<PuzzlePieceGenerator>();
            float[] bottomNeighborOffsets = bottomNeighbor.GetOffsets();

            // Grab the top offset
            float neighborTopOffset = bottomNeighborOffsets[3];

            // Apply the opposite edge offset
            bottom = 1 - neighborTopOffset;
        }

        if (IsValidGridPos(x - 1, y))
        {
            PuzzlePieceGenerator leftNeighbor = transform.GetChild(GridPosToIndex(x - 1, y)).GetComponent<PuzzlePieceGenerator>();
            float[] leftNeighborOffsets = leftNeighbor.GetOffsets();

            // Grab the right offset
            float neighborRightOffset = leftNeighborOffsets[0];

            // Apply the opposite edge offset
            left = neighborRightOffset;
        }

        // Set random right & up if possible
        if (IsValidGridPos(x, y + 1))
            top = Constants.GetRandomKnobOffset();

        if (IsValidGridPos(x + 1, y))
            right = Constants.GetRandomKnobOffset();

        return new float[] { right, bottom, left, top };
    }

    private bool IsValidGridPos(int x, int y) => x >= 0 && x < gridSize.x && y >= 0 && y < gridSize.y;
    private int GetRandomEdge() => Random.Range(1, 3);

    public PuzzlePiece[] GetPieces()
    {
        return transform.GetComponentsInChildren<PuzzlePiece>();
    }

    private Vector3 GetPieceSpiralPosition(int index, float radius)
    {
        float x = radius * Mathf.Sqrt(index) * Mathf.Cos(Mathf.Deg2Rad * index * Constants.goldenAngle);
        float y = radius * Mathf.Sqrt(index) * Mathf.Sin(Mathf.Deg2Rad * index * Constants.goldenAngle);

        return new Vector3(x, y, 0);
    }
}
