using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutlineTester : MonoBehaviour
{
    public Vector2[] originalVertices; // Set this in the Inspector or programmatically
    private List<Vector2> insideVertices = new List<Vector2>();

    [SerializeField] private float thickness;
    [SerializeField] private float gizmosNormalLength;

    void Start()
    {

    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.white;

        for (int i = 0; i < originalVertices.Length; i++)
        {
            int nextIndex = (i + 1) % originalVertices.Length;

            Gizmos.DrawLine(originalVertices[i], originalVertices[nextIndex]);
            Gizmos.DrawWireSphere(originalVertices[i], .05f);
        }


        Gizmos.color = Color.red;
        insideVertices.Clear();
        insideVertices = Outliner2D.CreateInsideOutline(originalVertices, thickness);

        for (int i = 0; i < insideVertices.Count; i++)
        {
            int nextIndex = (i + 1) % insideVertices.Count;
            Gizmos.DrawLine(insideVertices[i], insideVertices[nextIndex]);
        }

        for (int i = 0; i < originalVertices.Length; i++)
        {
            int nextIndex = (i + 1) % originalVertices.Length;
            int previousIndex = i - 1;
            if (previousIndex < 0)
                previousIndex = originalVertices.Length - 1;

            Vector2 nextEdge = originalVertices[nextIndex] - originalVertices[i];
            Vector2 previousEdge = originalVertices[previousIndex] - originalVertices[i];

            Vector2 nextEdgeNormal = Vector3.Cross(nextEdge.normalized, Vector3.forward);
            Vector2 previousEdgeNormal = Vector3.Cross(Vector3.forward, previousEdge.normalized);

            Vector2 normalMean = ((nextEdgeNormal + previousEdgeNormal) / 2).normalized;
            
            Gizmos.color = Color.green;

            Gizmos.DrawLine(originalVertices[i], originalVertices[i] + nextEdgeNormal * gizmosNormalLength);
            Gizmos.DrawLine(originalVertices[nextIndex], originalVertices[nextIndex] + nextEdgeNormal* gizmosNormalLength);

            Gizmos.DrawLine(originalVertices[i], originalVertices[i] + previousEdgeNormal* gizmosNormalLength);
            Gizmos.DrawLine(originalVertices[previousIndex], originalVertices[previousIndex] + previousEdgeNormal* gizmosNormalLength);

            Gizmos.color = Color.blue;

            Gizmos.DrawLine(originalVertices[i], originalVertices[i] + normalMean * gizmosNormalLength * 2);

        }
    }

}