using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System;

public class PuzzleMuseumContainer : MonoBehaviour
{
    [Header(" Elements ")]
    [SerializeField] private Image puzzleImage;
    [SerializeField] private TextMeshProUGUI timeText;

    [Header(" Actions ")]
    public static Action<Sprite> onPointerDown;

    public void Configure(Sprite puzzleSprite, string timeString)
    {
        puzzleImage.sprite = puzzleSprite;
        timeText.text = timeString;
    }

    public void PointerDownCallback()
    {
        Debug.Log(name + " pointer down");
        onPointerDown?.Invoke(GetSprite());
    }

    public Sprite GetSprite()
    {
        return puzzleImage.sprite;
    }
}
