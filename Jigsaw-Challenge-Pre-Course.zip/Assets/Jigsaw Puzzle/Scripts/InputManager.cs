using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class InputManager : MonoBehaviour
{
    enum State { None, Piece, Camera }
    private State state;

    [Header(" Elements ")]
    [SerializeField] private PuzzleController puzzleController;

    Vector2 touch0ClickedPos, touch1ClickedPos;
    Vector2 initialDelta;

    [Header(" Actions ")]
    public static Action<Vector2> onBeganTouch;
    public static Action<Vector2> onTouching;
    public static Action<Vector2> onEndedTouch;

    public static Action<Vector2, Vector2> onDoubleTouchBegan;
    public static Action<float> onDoubleTouching;

    public static Action onPieceDoubleTouchBegan;
    public static Action<float> onPieceDoubleTouching;

    private void Awake()
    {
        state = State.None;
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance.IsPlaying())
            ManageGameInput();
    }

    private void ManageGameInput()
    {
        if (Input.touchCount == 1)
            ManageSingleTouch();        

        else if (Input.touchCount == 2)
            ManageDoubleTouch();        
    }

    private void ManageSingleTouch()
    {
        Vector2 touchPos = Input.touches[0].position;
        Vector3 worldPos = CameraUtils.GetWorldPosition(touchPos);
        TouchPhase touchPhase = Input.GetTouch(0).phase;

        switch (touchPhase)
        {
            case TouchPhase.Began:
                if (puzzleController.MouseDownCallback(worldPos))
                {
                    // We are going to move a puzzle piece
                    state = State.Piece;
                    break;
                }

                // We did not hit a puzzle piece, start moving the camera
                onBeganTouch?.Invoke(touchPos);
                state = State.Camera;

                break;

            case TouchPhase.Moved:

                if (state == State.Piece)
                    puzzleController.MouseDragCallback(worldPos);

                else if (state == State.Camera)
                    onTouching?.Invoke(touchPos);
                
                break;


            case TouchPhase.Ended:

                if (state == State.Piece)
                    puzzleController.MouseUpCallback(worldPos);

                if (state == State.Camera)
                    onEndedTouch?.Invoke(touchPos);

                state = State.None;
                break;
        }
    }

    private void ManageDoubleTouch()
    {
        switch (state)
        {
            case State.Camera:
                ManageCameraDoubleTouch();
                break;

            case State.Piece:
                ManagePieceDoubleTouch();
                break;

            case State.None:
                state = State.Camera;
                ManageCameraDoubleTouch();
                break;
        }
    }

    private void ManageCameraDoubleTouch()
    {
        Touch[] touches = Input.touches;

        if(touches[0].phase == TouchPhase.Began)
            touch0ClickedPos = touches[0].position;
        
        // Store the second finger initial pos
        if (touches[1].phase == TouchPhase.Began)
        {
            touch0ClickedPos = touches[0].position;
            touch1ClickedPos = touches[1].position;
            initialDelta = touch1ClickedPos - touches[0].position;

            onDoubleTouchBegan?.Invoke(touch0ClickedPos, touch1ClickedPos);
            return;
        }

        // We need the initial difference between these touches
        Vector2 currentDelta = touches[1].position - touches[0].position;
        float distanceDelta = (currentDelta.magnitude - initialDelta.magnitude) / Screen.width;

        onDoubleTouching?.Invoke(distanceDelta);

        // Prevent weird camera movement after zoom
        // Player will need to release and press again with one finger
        foreach (Touch touch in Input.touches)
            if (touch.phase == TouchPhase.Ended)
                state = State.None;
    }

    private void ManagePieceDoubleTouch()
    {
        if (!DifficultyManager.instance.IsRotationOn())
            return;

        Touch[] touches = Input.touches;

        // Only the second finger will be responsible for rotating the piece
        // Store the second finger initial pos
        if (touches[1].phase == TouchPhase.Began)
        {
            touch1ClickedPos = touches[1].position;
            puzzleController.StartRotatingPiece();
            //onPieceDoubleTouchBegan?.Invoke();
        }

        float xDelta = (touches[1].position.x - touch1ClickedPos.x) / Screen.width;

        puzzleController.RotatePiece(xDelta);
    }
}
