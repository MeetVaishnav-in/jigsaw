= Native Camera for Android & iOS (v1.4.2) =

Documentation: https://github.com/yasirkula/UnityNativeCamera
FAQ: https://github.com/yasirkula/UnityNativeCamera#faq
Example code: https://github.com/yasirkula/UnityNativeCamera#example-code
E-mail: yasirkula@gmail.com